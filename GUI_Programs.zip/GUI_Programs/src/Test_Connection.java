/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */

import java.sql.*;

public class Test_Connection {
    
    public static void main(String[] args){
        
        try{
            
            Class.forName("com.mysql.jdbc.Driver"); // drive class name
                Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Java_Adv","root","1234"); // database path
            System.out.println("success");
            
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
        
    }
    
}
